import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

import com.mysql.jdbc.NdbLoadBalanceExceptionChecker;

class StartWindow extends Frame implements ActionListener {

	private Button joinButton, loginButton;
	private Label title1, title2;

	public static Connection conn;
	public static Statement stmt;
	public static ResultSet rs;

	public static String userId;
	public static String UserPassWor;

	/**
	 * start main window part used system part argument
	 * 
	 * @param args
	 */

	public static void main(String args[]) {

		/*
		 * mysql connection part
		 */

		String driver = "com.mysql.jdbc.Driver";
		String user = "root";
		String pass = "1234";
		String dbURL = "jdbc:mysql://localhost:3306/airline";
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(dbURL, user, pass);
			stmt = conn.createStatement();
			rs = null;
			System.out.println("Driver found! Connection Good!");
		} catch (SQLException se) {
			System.out.println("sql error");
		} catch (ClassNotFoundException cne) {
			System.out.println("jdbc driver not founded!");
		}
		
		new StartWindow();
	}

	public static boolean celculate(int _nYear, int _nMonth, int _nDay) {
		if ((2 == _nMonth && _nDay > 28) || (6 == _nMonth && _nDay > 30)
				|| (9 == _nMonth && _nDay > 30)
				|| (11 == _nMonth && _nDay > 30)
				|| (3 == _nMonth && _nDay > 30)) {
			new DialogAlarm(_nMonth, _nDay);
			return false;
		}

		return true;
	}

	/**
	 * constuctor
	 */
	public StartWindow() {
		// TODO Auto-generated constructor stub

		setBounds(200, 200, 140, 140);
		setVisible(true);
		addWindowListener(new windowadapter(this));
		
		title1 = new Label("KOREA TECH", Label.CENTER);
		title2 = new Label("Airline Client", Label.CENTER);

		joinButton = new Button("����");
		loginButton = new Button("�α���");
		JPanel pn1 = new JPanel();
		JPanel pn2 = new JPanel();
		JPanel pn3 = new JPanel();
		setLayout(new GridLayout(3, 1));
		setResizable(false);

		pn1.add(title1);
		pn3.add(title2);
		pn2.add(joinButton);
		pn2.add(loginButton);

		add(pn1);
		add(pn3);
		add(pn2);

		joinButton.addActionListener(this);
		loginButton.addActionListener(this);

	}

	/**
	 * actionPerform part
	 */

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == joinButton) {
			System.out.println("you enter the join part");
			new JoinWindow();
			this.dispose();

		} else if (e.getSource() == loginButton) {
			System.out.println("you enter the login part");
			new LoginWindow();
			this.dispose();

		}
	}

}

/**
 * 
 * @author Kjw Joinwindow ���� ������ �κ�. �������� ������ ����Ǿ��ִ�.
 * 
 */

class JoinWindow extends Frame implements ActionListener {
	boolean isIdCheck = false;

	Button btRegister, btBack, btCheckDuplicate;
	TextField tfIdFiyld, tfPassword, tfName, tfEMail, tfPhoneFront,
			tfPhoneAfter, tfPassportNumber, tfAddress, tfMailAddress, tfMoney,
			tfPasswordCheck;
	Checkbox RbMale, RbFemale;
	CheckboxGroup bgSex;
	JComboBox<String> cbPhone, cbYear, cbMonth, cbDay;
	String cbhp[] = { "010", "011", "016", "017", "018", "019" };
	String cbyear[] = { "2013", "2014", "2015", "2016", "2017", "2018", "2019",
			"2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027",
			"2028", "2029", "2030" };
	String cbmonth[] = { "01", "02", "03", "04", "05", "06", "07", "08", "09",
			"10", "11", "12" };
	String cbdate[] = { "01", "02", "03", "04", "05", "06", "07", "08", "09",
			"10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
			"21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };

	public JoinWindow() {
		setBounds(200, 200, 350, 430);
		setVisible(true);
		JPanel pn1 = new JPanel();
		JPanel pn2 = new JPanel();
		JPanel pn3 = new JPanel();
		JPanel pn4 = new JPanel();
		JPanel pn5 = new JPanel();
		JPanel pn6 = new JPanel();
		JPanel pn7 = new JPanel();
		JPanel pn8 = new JPanel();
		JPanel pn9 = new JPanel();
		JPanel JpPassWordCheck = new JPanel();
		JPanel JpMailAddress = new JPanel();
		JPanel JpAddress = new JPanel();
		JPanel JpMoney = new JPanel();
		Label lbAddress = new Label("�ּ�", Label.CENTER);
		Label lbMailAddress = new Label("����", Label.CENTER);
		Label lbID = new Label("ID", Label.CENTER);
		Label ldPassword = new Label("PASSWORD", Label.CENTER);
		Label LdPasswordCheck = new Label("Check", Label.CENTER);
		Label lbName = new Label("�̸�", Label.CENTER);
		Label lbEMail = new Label("E-MAIL", Label.CENTER);
		Label lbPhone = new Label("��ȭ��ȣ", Label.CENTER);
		Label lbSex = new Label("����", Label.CENTER);
		Label lbPassportNumber = new Label("���� ��ȣ", Label.CENTER);
		Label lbExpire = new Label("���� �Ⱓ", Label.CENTER);
		Label lbMoney = new Label("�Աݾ�", Label.CENTER);
		tfMoney = new TextField(7);
		tfAddress = new TextField(15);
		tfMailAddress = new TextField(5);
		tfIdFiyld = new TextField(15);
		tfPassword = new TextField(20);
		tfPasswordCheck = new TextField(20);
		tfName = new TextField(10);
		tfEMail = new TextField(30);
		tfPhoneFront = new TextField(4);
		tfPhoneAfter = new TextField(4);
		tfPassportNumber = new TextField(20);
		bgSex = new CheckboxGroup();
		RbMale = new Checkbox("����", bgSex, true);
		RbFemale = new Checkbox("����", bgSex, false);
		cbPhone = new JComboBox<String>(cbhp);
		cbYear = new JComboBox<String>(cbyear);
		cbMonth = new JComboBox<String>(cbmonth);
		cbDay = new JComboBox<String>(cbdate);
		setLayout(new FlowLayout(FlowLayout.LEADING));
		setResizable(false);
		btRegister = new Button("����");
		btBack = new Button("�ڷ�");
		btCheckDuplicate = new Button("�ߺ� Ȯ��");

		add(pn1);
		pn1.add(lbID);
		pn1.add(tfIdFiyld);
		pn1.add(btCheckDuplicate);
		add(pn2);
		pn2.add(ldPassword);
		pn2.add(tfPassword);
		tfPassword.setEchoChar('+');
		add(JpPassWordCheck);
		JpPassWordCheck.add(LdPasswordCheck);
		JpPassWordCheck.add(tfPasswordCheck);
		tfPasswordCheck.setEchoChar('*');
		add(pn3);
		pn3.add(lbName);
		pn3.add(tfName);
		add(pn4);
		pn4.add(lbSex);
		pn4.add(RbMale);
		pn4.add(RbFemale);
		add(JpMailAddress);
		JpMailAddress.add(lbMailAddress);
		JpMailAddress.add(tfMailAddress);
		add(JpAddress);
		JpAddress.add(lbAddress);
		JpAddress.add(tfAddress);
		add(pn5);
		pn5.add(lbEMail);
		pn5.add(tfEMail);
		add(pn6);
		pn6.add(lbPhone);
		pn6.add(cbPhone);
		pn6.add(tfPhoneFront);
		pn6.add(tfPhoneAfter);
		add(pn8);
		pn8.add(lbPassportNumber);
		pn8.add(tfPassportNumber);
		add(pn9);
		pn9.add(lbExpire);
		pn9.add(cbYear);
		pn9.add(cbMonth);
		pn9.add(cbDay);
		add(JpMoney);
		JpMoney.add(lbMoney);
		JpMoney.add(tfMoney);
		add(pn7);
		pn7.add(btRegister);
		pn7.add(btBack);

		btCheckDuplicate.addActionListener(this);
		btRegister.addActionListener(this);
		btBack.addActionListener(this);

		this.addWindowListener(new windowadapter(this));
	}

	/**
	 * actioPermformed �̹�Ʈ ó���ϴ� �κ�.
	 */

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btRegister) {

			if (0 == tfPassword.getText().compareTo(tfPasswordCheck.getText())) {

			} else {
				new DialogSuccess("���� ����", "��й�ȣ��", "�߸� ����ϴ�..", 100, 100);
				return;
			}

			if (0 == tfIdFiyld.getText().compareTo("")
					|| 0 == tfAddress.getText().compareTo("")
					|| 0 == tfEMail.getText().compareTo("")
					|| 0 == tfIdFiyld.getText().compareTo("")
					|| 0 == tfMailAddress.getText().compareTo("")
					|| 0 == tfMoney.getText().compareTo("")
					|| 0 == tfName.getText().compareTo("")
					|| 0 == tfPassportNumber.getText().compareTo("")
					|| 0 == tfPassword.getText().compareTo("")
					|| 0 == tfPhoneAfter.getText().compareTo("")
					|| 0 == tfPhoneFront.getText().compareTo("")) {
				this.dispose();
				System.out.println(tfIdFiyld.getText() + "��ĭ ����.");

				new DialogSuccess("���� ����", "�Է�", "���� �����ϴ�.", 100, 100);

				new StartWindow();

				return;
			}

			if (false == StartWindow.celculate(
					Integer.parseInt(cbYear.getSelectedItem().toString()),
					Integer.parseInt(cbMonth.getSelectedItem().toString()),
					Integer.parseInt(cbDay.getSelectedItem().toString()))) {

				System.out.println("fail register");
				new StartWindow();
				this.dispose();

				return;
			} else {
				try {

					String query = "select * from client where id ='"
							+ tfIdFiyld.getText() + "'";
					StartWindow.rs = StartWindow.stmt.executeQuery(query);

					if (false == StartWindow.rs.next()) {

						String gender;

						if (0 == bgSex.getSelectedCheckbox().getLabel()
								.toString().compareTo("����")) {
							gender = "M";
						} else {
							gender = "W";
						}

						String query1 = "INSERT INTO client VALUES (" + "'"
								+ tfIdFiyld.getText() + "', '"
								+ tfPassword.getText() + "', '"
								+ tfName.getText() + "', '" + gender + "', '"
								+ cbPhone.getSelectedItem().toString() + "-"
								+ tfPhoneFront.getText() + "-"
								+ tfPhoneAfter.getText() + "', '"
								+ tfEMail.getText() + "', '"
								+ tfMailAddress.getText() + "', '"
								+ tfAddress.getText() + "', " + 0 + ", "
								+ Integer.parseInt(tfMoney.getText()) + ", '"
								+ tfPassportNumber.getText() + "' ,'"
								+ cbYear.getSelectedItem().toString() + "-"
								+ cbMonth.getSelectedItem().toString() + "-"
								+ cbDay.getSelectedItem().toString() + "')";
						StartWindow.stmt.executeUpdate(query1);

						this.dispose();
						System.out.println(tfIdFiyld.getText() + "���̰��ԵǾ����ϴ�");

						new DialogSuccess("���� ����", tfIdFiyld.getText(),
								"���Կ� �����ϼ̽��ϴ�.", 150, 100);

						new StartWindow();
						return;
					} else {
						this.dispose();
						System.out.println(tfIdFiyld.getText() + "���̵�� �����մϴ�.");

						new DialogSuccess("���� ����", tfIdFiyld.getText(),
								"���Կ� �����Ͽ����ϴ�.", 150, 100);

						new StartWindow();
						return;
					}

				} catch (SQLException e1) {
					System.err.println("error sql = " + e1);
				}

			}

		} else if (e.getSource() == btBack) {

			System.out.println("you enter the start window");
			new StartWindow();
			this.dispose();

		} else if (e.getSource() == btCheckDuplicate) {
			String query = "select * from client where id ='"
					+ tfIdFiyld.getText() + "'";
			try {
				StartWindow.rs = StartWindow.stmt.executeQuery(query);

				if (false == StartWindow.rs.next()) {

					new DialogSuccess("��� ���� ���̵��Դϴ�", tfIdFiyld.getText(),
							"��� ������ ���̵��Դϴ�.", 200, 100);
					isIdCheck = true;
					return;
				} else {
					new DialogSuccess("��� �� �� �����ϴ�.", tfIdFiyld.getText(),
							"��� �� �� ���� ���̵� �Դϴ�.", 200, 100);
					isIdCheck = false;
					return;
				}

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}

}

/**
 * 
 * LoginWindow �α����� �������ִ� ��Ʈ
 * 
 * @author Kjw
 * 
 */

class LoginWindow extends Frame implements ActionListener {
	Button btLogin, btBack;
	TextField tfId, tfPassWord;

	public LoginWindow() {
		setBounds(200, 200, 220, 120);
		setVisible(true);
		setResizable(false);
		System.out.println("login window");
		Label lbId = new Label("���̵�", Label.CENTER);
		Label lbPassWord = new Label("��й�ȣ", Label.CENTER);
		tfId = new TextField(10);
		tfPassWord = new TextField(10);
		setLayout(new FlowLayout());
		setResizable(false);
		btLogin = new Button("�α���");
		btBack = new Button("�ڷ�");

		add(lbId);
		add(tfId);
		add(lbPassWord);
		add(tfPassWord);
		add(btLogin);
		add(btBack);
		btLogin.addActionListener(this);
		btBack.addActionListener(this);

		this.addWindowListener(new windowadapter(this));
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btLogin) {

			try {
				String query = "select * from client where id ="
						+ tfId.getText().toString() + " and " + "password ="
						+ tfPassWord.getText().toString() + "";
				StartWindow.rs = StartWindow.stmt.executeQuery(query);

				if (false == StartWindow.rs.next()) {
					new DialogSuccess("�α��� ����", tfId.getText(), "�� �������� �ʽ��ϴ�.",
							150, 100);
					System.out.println("you enter the StartWindow");
					return;
				} else {
					new DialogSuccess("�α��� ����", tfId.getText(), "�� �ȳ��ϼ���!",
							150, 100);
					StartWindow.userId = tfId.getText();
					StartWindow.UserPassWor = tfPassWord.getText();
					System.out.println(tfId.getText() + "���̷α��εǾ����ϴ�. �����"
							+ tfPassWord.getText());
					new AfterLoginWindow();
					this.dispose();
					return;
				}
			} catch (SQLException e1) {
				System.err.println("error sql = " + e1);
			}

		} else if (e.getSource() == btBack) {

			System.out.println("you enter the StartWindow");
			new StartWindow();
			this.dispose();
			return;

		}
	}

}

/**
 * �α��� �� ���� �������� Ŭ����
 * 
 * @author Kjw
 * 
 */

class AfterLoginWindow extends Frame implements ActionListener {
	Button btImfo, btDoRever, btOverReser, btLogout;

	public AfterLoginWindow() {

		setBounds(200, 200, 220, 150);
		setVisible(true);
		setResizable(false);
		setLayout(new GridLayout(4, 1));
		setBounds(200, 200, 220, 150);
		setResizable(false);
		btImfo = new Button("����");
		btDoRever = new Button("������ ����");
		btOverReser = new Button("������ ����");
		btLogout = new Button("�α׾ƿ�");

		add(btImfo);
		add(btDoRever);
		add(btOverReser);
		add(btLogout);
		btImfo.addActionListener(this);
		btDoRever.addActionListener(this);
		btOverReser.addActionListener(this);
		btLogout.addActionListener(this);

		this.addWindowListener(new windowadapter(this));
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btImfo) {

			new TabWindow();
			this.setVisible(false);

		} else if (e.getSource() == btDoRever) {

			new DomainReservationWindow();
			this.dispose();

		} else if (e.getSource() == btOverReser) {
			System.out.println("you enter the OverseaReservation window");
			new OverseaReservation();
			this.dispose();
		} else if (e.getSource() == btLogout) {
			System.out.println("you enter LogWindow");
			new StartWindow();
			this.dispose();
			this.setVisible(false);
		}
	}

}

/**
 * ������ ���� ��Ʈ
 * 
 * @author Kjw
 * 
 */

class DomainReservationWindow extends Frame implements ActionListener {

	static String sStartPostion, sDestniPosition, sStartYear, sStartMonth,
			sStartDay, sPersonAdult, sEndYear, sEndMonth, sEndDay,
			sPersonChild, sSeatSort;

	Button BtRegister, BtBack, b3;
	Checkbox usually, first;
	CheckboxGroup bg, CgSeatSet;
	JComboBox<String> cbStartPosition, cbYear, cbMonth, cbDay, cbDestiYear,
			cbDestiMonth, cbDestiDay, cbDestniposition, cbAdult, cbChild;
	String lsStartPosition[] = { "����", "����", "�뱸", "�λ�", "����", "��õ", "����",
			"���", "����", "����", "����", "û��", "����" };
	String lsDestniPosition[] = { "����", "�λ�", "����", "���", "����", "����", "����" };

	String cbyear[] = { "2013", "2014", "2015", "2016", "2017", "2018", "2019",
			"2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027",
			"2028", "2029", "2030" };
	String cbmonth[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
			"11", "12" };
	String cbdate[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
			"11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
			"22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
	String lsPersonAdult[] = { "����0", "����1", "����2", "����3", "����4", "����5", "����6",
			"����7", "����8", "����9" };
	String lsPersonChild[] = { "�Ҿ�0", "�Ҿ�1", "�Ҿ�2", "�Ҿ�3", "�Ҿ�4", "�Ҿ�5", "�Ҿ�6",
			"�Ҿ�7", "�Ҿ�8", "�Ҿ�9" };

	public DomainReservationWindow() {
		setBounds(200, 200, 300, 290);
		setVisible(true);
		System.out.println("domain register");
		JPanel pn1 = new JPanel();
		JPanel pn2 = new JPanel();
		JPanel pn3 = new JPanel();
		JPanel pn4 = new JPanel();
		JPanel pn5 = new JPanel();
		JPanel pn6 = new JPanel();
		Label lb1 = new Label("�¼� ����", Label.CENTER);
		Label lb2 = new Label("���ü���", Label.CENTER);
		Label lb3 = new Label("���� �ο�", Label.CENTER);
		Label lb4 = new Label("��ȯ ��¥", Label.CENTER);
		Label lb5 = new Label("��� ��¥", Label.CENTER);

		CgSeatSet = new CheckboxGroup();
		usually = new Checkbox("�Ϲݼ�", CgSeatSet, true);

		first = new Checkbox("������Ƽ����", CgSeatSet, false);
		cbStartPosition = new JComboBox<String>(lsStartPosition);

		cbYear = new JComboBox<String>(cbyear);
		cbMonth = new JComboBox<String>(cbmonth);
		cbDay = new JComboBox<String>(cbdate);

		cbDestiYear = new JComboBox<String>(cbyear);
		cbDestiMonth = new JComboBox<String>(cbmonth);
		cbDestiDay = new JComboBox<String>(cbdate);

		cbDestniposition = new JComboBox<String>(lsDestniPosition);
		cbAdult = new JComboBox<String>(lsPersonAdult);
		cbChild = new JComboBox<String>(lsPersonChild);
		setLayout(new FlowLayout(FlowLayout.LEADING));
		BtRegister = new Button("����");
		BtBack = new Button("�ڷ�");
		add(pn5);
		pn5.add(lb1);
		pn5.add(usually);
		pn5.add(first);
		add(pn2);
		pn2.add(lb2);
		pn2.add(cbStartPosition);
		pn2.add(cbDestniposition);
		add(pn3);
		pn3.add(lb3);
		pn3.add(cbAdult);
		pn3.add(cbChild);
		add(pn4);
		pn4.add(lb5);
		pn4.add(cbYear);
		pn4.add(cbMonth);
		pn4.add(cbDay);

		add(pn1);
		pn1.add(lb4);
		pn1.add(cbDestiYear);
		pn1.add(cbDestiMonth);
		pn1.add(cbDestiDay);

		add(pn6);
		pn6.add(BtRegister);
		pn6.add(BtBack);

		BtRegister.addActionListener(this);
		BtBack.addActionListener(this);
		this.addWindowListener(new windowadapter(this));
		setResizable(false);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == BtRegister) {

			if (false == StartWindow.celculate(
					Integer.parseInt(cbYear.getSelectedItem().toString()),
					Integer.parseInt(cbMonth.getSelectedItem().toString()),
					Integer.parseInt(cbDay.getSelectedItem().toString()))) {

				System.out.println("fail reservation");
				new StartWindow();
				this.dispose();

				return;
			} else {

				if (0 == CgSeatSet.getSelectedCheckbox().getLabel().toString()
						.compareTo("�Ϲݼ�")) {
					sSeatSort = "economic_seat";
				} else {
					sSeatSort = "business_seat";
				}

				System.out.println("success reservation");
				sStartDay = cbDay.getSelectedItem().toString();
				sDestniPosition = cbDestniposition.getSelectedItem().toString();
				sStartMonth = cbMonth.getSelectedItem().toString();
				sPersonAdult = cbAdult.getSelectedItem().toString();
				sPersonChild = cbChild.getSelectedItem().toString();
				sStartPostion = cbStartPosition.getSelectedItem().toString();
				sStartYear = cbYear.getSelectedItem().toString();
				sEndDay = cbDestiDay.getSelectedItem().toString();
				sEndMonth = cbDestiMonth.getSelectedItem().toString();
				sEndYear = cbDestiYear.getSelectedItem().toString();

				System.out.println("you enter the RegisterDetail Window");
				new RegisterDetail();

				setVisible(false);
				this.dispose();

			}

		} else if (e.getSource() == BtBack) {

			System.out.println("you enter user afterLogWindow");
			new AfterLoginWindow();
			setVisible(false);
			dispose();
			this.dispose();
			return;

		}
	}

}

/**
 * ������ ���� ��Ʈ
 * 
 * @author Kjw
 * 
 */

class OverseaReservation extends Frame implements ActionListener {
	Button b1, b2;
	ButtonGroup bg, bg2;
	JComboBox<String> a1, a2, a3, a4, cbYear, cbMonth, cbDay, a8, a9,
			cbDestiYear, cbDestiMonth, cbDestiDay;
	JRadioButton usually, first;
	String arriveN[] = { "�ߵ�/������ī", "�߱�", "�Ϻ�", "����", "����", "���þ�/����/�߾Ӿƽþ�",
			"��/�����ƽþ�", "�����/��" };
	String year[] = { "2013", "2014", "2015", "2016", "2017", "2018", "2019",
			"2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027",
			"2028", "2029", "2030" };
	String month[] = { "01", "02", "03", "04", "05", "06", "07", "08", "09",
			"10", "11", "12" };
	String day[] = { "01", "02", "03", "04", "05", "06", "07", "08", "09",
			"10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
			"21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
	String Person3[] = { "����1", "����2", "����3", "����4", "����5", "����6", "����7",
			"����8", "����9" };
	String Person4[] = { "�Ҿ�1", "�Ҿ�2", "�Ҿ�3", "�Ҿ�4", "�Ҿ�5", "�Ҿ�6", "�Ҿ�7",
			"�Ҿ�8", "�Ҿ�9" };

	public OverseaReservation() {
		setBounds(200, 200, 300, 320);
		setVisible(true);
		System.out.println("oversea register");
		Label lb2 = new Label("�����");
		Label lb3 = new Label("������");
		Label lb4 = new Label("��� ��¥");
		Label lb5 = new Label("�ͱ� ��¥");
		Label lb6 = new Label("�¼�����");
		setLayout(new FlowLayout());
		JPanel n2 = new JPanel();
		JPanel n3 = new JPanel();
		JPanel n4 = new JPanel();
		JPanel n5 = new JPanel();
		JPanel n6 = new JPanel();
		b1 = new Button("����");
		b2 = new Button("�ڷ�");
		usually = new JRadioButton("�Ϲݼ�");
		first = new JRadioButton("������Ƽ����");
		a1 = new JComboBox<String>(arriveN);
		a2 = new JComboBox<String>();
		a3 = new JComboBox<String>();
		a4 = new JComboBox<String>();
		cbYear = new JComboBox<String>(year);
		cbMonth = new JComboBox<String>(month);
		cbDay = new JComboBox<String>(day);

		cbDestiYear = new JComboBox<String>(year);
		cbDestiMonth = new JComboBox<String>(month);
		cbDestiDay = new JComboBox<String>(day);
		a8 = new JComboBox<String>(Person3);
		a9 = new JComboBox<String>(Person4);
		bg = new ButtonGroup();
		bg2 = new ButtonGroup();
		bg2.add(usually);
		bg2.add(first);
		add(n2);
		n2.add(lb2);
		n2.add(a1);
		n2.add(a2);
		add(n3);
		n3.add(lb3);
		n3.add(a3);
		n3.add(a4);
		add(n4);
		n4.add(lb4);
		n4.add(cbYear);
		n4.add(cbMonth);
		n4.add(cbDay);
		add(n5);
		n5.add(lb5);
		n5.add(cbDestiYear);
		n5.add(cbDestiMonth);
		n5.add(cbDestiDay);
		add(n6);
		n6.add(lb6);
		n6.add(usually);
		n6.add(first);

		setLayout(new FlowLayout(FlowLayout.LEADING));
		add(b1);
		add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
		this.addWindowListener(new windowadapter(this));
		setResizable(false);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			System.out.println("you enter the RegisterDetail Window");
			new RegisterDetail();
			this.setVisible(false);
			this.dispose();

		} else if (e.getSource() == b2) {

			System.out.println("you enter AFterLoginWindow");
			new AfterLoginWindow();
			this.setVisible(false);
			this.dispose();

		}
	}

}

/**
 * ������ ���� ��Ʈ
 * 
 * @author Kjw
 * 
 */

class RegisterDetail extends Frame implements ActionListener {
	static boolean on = true;

	Button b1, b2, b3;
	ButtonGroup bg, bg2;
	JComboBox<String> cbTime;
	String time[] = { "10" };
	RegisterDetail frame2;

	public RegisterDetail() {
		setBounds(200, 200, 300, 290);
		setVisible(true);

		// sDestniPosition,sStartYear,sStartMonth,sStartDay,sPersonAdult,
		// sEndYear,sEndMonth,sEndDay,sPersonChild,sSeatSort;

		String query, query1;

		if (0 == DomainReservationWindow.sSeatSort.compareTo("economic_seat")) {
			query = "select  economic_seat,start_hour, start_min , start_sec , end_hour ,end_min ,end_sec from flying where start_place ='"
					+ DomainReservationWindow.sStartPostion
					+ "'"
					+ " and end_place ='"
					+ DomainReservationWindow.sDestniPosition
					+ "'"
					+ " and economic_seat > 0";

			query1 = "select economic_cost from cost where departure ='"
					+ DomainReservationWindow.sStartPostion + "'"
					+ " and dest ='" + DomainReservationWindow.sDestniPosition
					+ "'";
		} else {
			query = "select business_seat ,start_hour, start_min , start_sec , end_hour ,end_min ,end_sec from flying where start_place ='"
					+ DomainReservationWindow.sStartPostion
					+ "'"
					+ " and end_place ='"
					+ DomainReservationWindow.sDestniPosition
					+ "'"
					+ " and business_seat > 0";

			query1 = "select business_cost from cost where departure ='"
					+ DomainReservationWindow.sStartPostion + "'"
					+ " and dest ='" + DomainReservationWindow.sDestniPosition
					+ "'";

		}

		int i = 0;

		try {
			StartWindow.rs = StartWindow.stmt.executeQuery(query);
			if (StartWindow.rs.next()) {
				time[i] = StartWindow.rs.getString(2) + ":"
						+ StartWindow.rs.getString(3) + ":"
						+ StartWindow.rs.getString(4);

				i++;

			}

			if (i == 0 && true == on) {
				new DialogSuccess("������ �����ϴ�", "���� ����", " �������� �ʽ��ϴ�.",
						150, 100);
				new AfterLoginWindow();
				System.out.println("���� ������ �����ϴ�.");
				on = false;
				this.dispose();
				return ;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			StartWindow.rs = StartWindow.stmt.executeQuery(query1);
			if (StartWindow.rs.next()) {

				int num = StartWindow.rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JPanel pn1 = new JPanel();
		JPanel pn2 = new JPanel();
		JPanel pn3 = new JPanel();
		JPanel pn4 = new JPanel();
		JPanel pn6 = new JPanel();
		Label lb1 = new Label("�ð� : ", Label.CENTER);
		Label lb2 = new Label("��� : ", Label.CENTER);
		Label lb3 = new Label("���� �ο� : ", Label.CENTER);
		Label lb4 = new Label("���� �ð� : ");

		Label lbanswer1 = new Label(" ", Label.CENTER);
		Label lbanswer2 = new Label(" ", Label.CENTER);
		Label lbanswer3 = new Label(" ", Label.CENTER);

		cbTime = new JComboBox<String>(time);
		setLayout(new GridLayout(5, 1));
		b1 = new Button("����");
		b2 = new Button("�ڷ�");

		add(pn4);
		pn4.add(lb4);
		pn4.add(cbTime);

		add(pn1);
		pn1.add(lb1);
		pn1.add(lbanswer1);

		add(pn2);
		pn2.add(lb2);
		pn2.add(lbanswer2);

		add(pn3);
		pn3.add(lb3);
		pn3.add(lbanswer3);

		add(pn6);
		pn6.add(b1);
		pn6.add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
		this.addWindowListener(new windowadapter(this));
		setResizable(false);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b1) {
			// ������ �ߴ� ���̾�α׿� ���н� �ߴ� ���̾�α� �ٸ���

		} else if (e.getSource() == b2) {

			System.out.println("you enter user startWindow");
			RegisterDetail.on = true;
			new AfterLoginWindow();
			this.dispose();
			return;

		}
	}

}

/**
 * ����� �������� ��Ʈ
 * 
 * @author Kjw
 * 
 */
class TabWindow extends Frame implements ActionListener {

	static TabWindow tabWindow = new TabWindow();
	private Button b1;
	TabWindow frame3;

	private static Box recoder() {

		Box panel = new Box(BoxLayout.X_AXIS);
		JLabel label = new JLabel("���� ���  " + "user" + ":", JLabel.LEFT);
		label.setAlignmentY(JLabel.TOP_ALIGNMENT);

		String sRecord = "";
		String query = "select * from Flightrecord where client_id = "
				+ StartWindow.userId.toString();

		try {
			StartWindow.rs = StartWindow.stmt.executeQuery(query);
			while (StartWindow.rs.next()) {

				sRecord = StartWindow.rs.getString(2); // rs.getInt("num");

				/*
				 * java.sql.Date date = StartWindow.rs.getDate(4); //
				 * rs.getDate("date"); java.util.Date d = new
				 * java.util.Date(date.getTime()); System.out.println(num +
				 * "\t"); System.out.println(name + "\t");
				 * System.out.println(jumin + "\t");
				 * System.out.println(d.toString());
				 */
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JTextArea text = new JTextArea(10, 16);
		JScrollPane scrollpane1 = new JScrollPane();
		scrollpane1
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		text.setAlignmentY(JTextField.TOP_ALIGNMENT);

		text.append(sRecord);
		text.setEditable(false);

		int position = text.getText().length();
		text.setCaretPosition(position);
		// label.add(scrollpane1);
		panel.add(label);
		panel.add(text);
		panel.add(scrollpane1, BorderLayout.CENTER);
		scrollpane1.getViewport().add(text, null);
		scrollpane1.getVerticalScrollBar().setValue(
				scrollpane1.getVerticalScrollBar().getMinimum());
		return panel;
	}

	private static Box imformation() {

		Box panel = new Box(BoxLayout.Y_AXIS);

		JPanel infor1 = new JPanel();
		JPanel infor2 = new JPanel();
		JPanel infor3 = new JPanel();
		JPanel infor4 = new JPanel();
		JPanel infor5 = new JPanel();
		JPanel infor6 = new JPanel();
		JPanel infor7 = new JPanel();

		infor1.setLayout(new FlowLayout(FlowLayout.LEFT));
		infor2.setLayout(new FlowLayout(FlowLayout.LEFT));
		infor3.setLayout(new FlowLayout(FlowLayout.LEFT));
		infor4.setLayout(new FlowLayout(FlowLayout.LEFT));
		infor5.setLayout(new FlowLayout(FlowLayout.LEFT));
		infor6.setLayout(new FlowLayout(FlowLayout.LEFT));
		infor7.setLayout(new FlowLayout(FlowLayout.LEFT));

		String query = "select * from client where id = "
				+ StartWindow.userId.toString() + " and " + "password " + "= "
				+ StartWindow.UserPassWor.toString();

		String sId = "";
		String sPassword = "";
		String sName = "";
		String sSex = "";
		String sPhone = "";
		String sEMail = "";
		String sEMailAdrress = "";
		String sAddress = "";
		int nCash = 0;
		int nMileage = 0;
		String sPassPortNum = "";

		try {
			StartWindow.rs = StartWindow.stmt.executeQuery(query);
			while (StartWindow.rs.next()) {

				sId = StartWindow.rs.getString(1); // rs.getInt("num");
				sPassword = StartWindow.rs.getString(2); // rs.getString("name");
				sName = StartWindow.rs.getString(3); // rs.getString("jumin");
				sSex = StartWindow.rs.getString(4);
				sPhone = StartWindow.rs.getString(5);
				sEMail = StartWindow.rs.getString(6);
				sEMailAdrress = StartWindow.rs.getString(7);
				sAddress = StartWindow.rs.getString(8);
				nCash = StartWindow.rs.getInt(10);
				nMileage = StartWindow.rs.getInt(9);
				sPassPortNum = StartWindow.rs.getString(11);
				/*
				 * java.sql.Date date = StartWindow.rs.getDate(4); //
				 * rs.getDate("date"); java.util.Date d = new
				 * java.util.Date(date.getTime()); System.out.println(num +
				 * "\t"); System.out.println(name + "\t");
				 * System.out.println(jumin + "\t");
				 * System.out.println(d.toString());
				 */
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JLabel JlID = new JLabel(sId);
		JLabel JlName = new JLabel(sName);
		JLabel JlSex = new JLabel(sSex);
		JLabel JlPassPort = new JLabel(sPassPortNum);
		JLabel JlAddress = new JLabel(sEMailAdrress + " " + sAddress);
		JLabel JlHanphoneNumber = new JLabel(sPhone);
		JLabel text7 = new JLabel("ddd");

		infor1.add(new JLabel("���� ID"));
		infor1.add(JlID);
		infor2.add(new JLabel("����"));
		infor2.add(JlName);
		infor3.add(new JLabel("����"));
		infor3.add(JlSex);
		infor4.add(new JLabel("PASSPORT"));
		infor4.add(JlPassPort);
		infor5.add(new JLabel("�ּ�"));
		infor5.add(JlAddress);
		infor6.add(new JLabel("�ڵ��� ��ȣ"));
		infor6.add(JlHanphoneNumber);
		infor7.add(new JLabel("��������"));
		infor7.add(text7);

		panel.add(infor1);
		panel.add(infor2);
		panel.add(infor3);
		panel.add(infor4);
		panel.add(infor5);
		panel.add(infor6);
		panel.add(infor7);
		return panel;
	}

	public TabWindow() {
		// TODO Auto-generated constructor stub

		JTabbedPane jtp = new JTabbedPane();
		jtp.addTab("������", recoder());
		jtp.addTab("��������", imformation());

		setBounds(200, 200, 220, 150);

		add(jtp, BorderLayout.CENTER);
		add(b1, BorderLayout.AFTER_LAST_LINE);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);

		setResizable(false);

		b1 = new Button("�ڷ�");
		this.addWindowListener(new windowadapter(this));
		this.setResizable(false);
		b1.addActionListener(this);

	}

	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == b1) {

			System.out.println("--");
			System.out.println("you enter afterwindow");
			new AfterLoginWindow();
			this.dispose();
			frame3.dispose();

		}
	}
}

/**
 * ������ ���� ó�� ��Ʈ
 * 
 * @author Kjw
 * 
 */

class windowadapter extends WindowAdapter {
	Frame m;

	windowadapter(Frame m) {
		this.m = m;
	}

	public void windowClosing(WindowEvent e) {
		m.dispose();
		System.out.println("GoodBy...");
		System.exit(1);
	}
}

class dialogAdapter extends WindowAdapter {
	Frame m;

	dialogAdapter(Frame m) {
		this.m = m;
	}

	public void windowClosing(WindowEvent e) {
		m.dispose();
		System.out.println("GoodBy...");
	}
}

class DialogSuccess extends Frame implements ActionListener {

	public DialogSuccess(String _sTitle, String _sComment1, String _sComment2,
			int _size_x, int _size_y) {
		Dialog d = new Dialog(this, _sTitle);
		Label LbMsg1 = new Label(_sComment1, Label.CENTER);
		Label LbMsg2 = new Label(_sComment2, Label.CENTER);
		d.setLayout(new GridLayout(2, 1));

		d.add(LbMsg1);
		d.add(LbMsg2);
		d.setSize(_size_x, _size_y);
		d.setLocation(300, 300);

		d.addWindowListener(new dialogAdapter(this));
		d.setVisible(true);
		d.setResizable(false);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}

}

class DialogAlarm extends Frame implements ActionListener {

	public DialogAlarm(int _nMonth, int _nDay) {
		Dialog d = new Dialog(this, "���");
		Label lbMsg = new Label(_nMonth + "/" + _nDay, Label.CENTER);
		Label lbCommant = new Label("�� ���� ��¥ �Դϴ�.", Label.CENTER);
		d.setLayout(new GridLayout(2, 1));

		d.add(lbMsg);
		d.add(lbCommant);
		d.setSize(100, 100);
		d.setLocation(300, 300);

		d.addWindowListener(new dialogAdapter(this));
		d.setVisible(true);
		d.setResizable(false);

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}
}
